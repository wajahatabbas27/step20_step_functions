declare const DynamoDB: any;
