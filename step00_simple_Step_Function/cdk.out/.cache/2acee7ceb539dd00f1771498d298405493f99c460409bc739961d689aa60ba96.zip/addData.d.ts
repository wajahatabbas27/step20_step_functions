declare const DynamoDb: any;
