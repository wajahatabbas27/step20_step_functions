declare type Event = {
    operationSuccessful: Boolean;
};
